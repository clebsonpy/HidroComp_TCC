from django.core.management import settings

default_app_config = '{}.apps.ODM2AdminConfig'.format(settings.APP_NAME)

__version__ = '0.1.0.dev'
